package com.ibm.connect.sdk.func.rowbased;

import com.ibm.connect.sdk.basic.impl.$_CONNNAMEPREFIX_$DatasourceType;

public class TestRowBasedDatasourceType extends $_CONNNAMEPREFIX_$DatasourceType
{

}
